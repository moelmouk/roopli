"""
Piège à fourmis "douve" pour tronc d'arbre
- 2 demi-anneaux identiques (imprimer le même STL x2)
- Clips en C séparés (imprimer x2) coulissant sur des oreilles en T
Tronc : Ø40 mm | Alésage : Ø50 mm | Canal : 20 x 15 mm | Jupe anti-pluie 45°
Unités : mm
"""
import numpy as np
import trimesh
from trimesh.creation import revolve, box

# ---------------- Paramètres ----------------
R_BORE   = 25.0   # rayon alésage (tronc 20 + 5 de jeu/mastic)
T_WALL   = 2.5    # épaisseur parois
R_IN     = R_BORE + T_WALL          # 27.5 : face interne du canal
CH_W     = 20.0                     # largeur canal
R_OUT_I  = R_IN + CH_W              # 47.5 : face externe du canal
R_OUT    = R_OUT_I + T_WALL         # 50.0 : extérieur anneau
Z_FLOOR  = 3.0    # épaisseur fond
Z_OWALL  = 18.0   # sommet paroi externe (canal prof. 15)
Z_SKIRT0 = 24.0   # départ jupe sur paroi interne
SK_TIP_R = 36.5   # rayon pointe de jupe
SK_TIP_Z = 15.0   # hauteur pointe (sous le sommet paroi ext -> goutte dans le canal)
Z_COLLAR = 26.0   # sommet du col contre le tronc
GAP      = 0.30   # jeu total entre les 2 moitiés (joint silicone)

# Oreilles en T (par moitié)
EAR_Z0, EAR_Z1 = 3.0, 15.0
STEM_R0, STEM_R1, STEM_HW = R_OUT, 54.0, 3.0    # pied : radial 50->54, demi-larg. tangentielle 3
CAP_R0,  CAP_R1,  CAP_HW  = 54.0, 57.0, 6.0     # tête : radial 54->57, demi-larg. 6

SECTIONS = 256

# ---------------- Profil de révolution (r, z) ----------------
profile = np.array([
    (R_BORE,  0.0),
    (R_OUT,   0.0),
    (R_OUT,   Z_OWALL),
    (R_OUT_I, Z_OWALL),
    (R_OUT_I, Z_FLOOR),
    (R_IN,    Z_FLOOR),
    (R_IN,    Z_SKIRT0),
    (SK_TIP_R, SK_TIP_Z),       # dessous de jupe à 45°
    (SK_TIP_R, SK_TIP_Z + 2.0), # pointe ép. 2
    (R_BORE,  Z_COLLAR),        # dessus de jupe -> col
    (R_BORE,  0.0),
])

ring = revolve(profile, sections=SECTIONS)
assert ring.is_watertight, "anneau non étanche"

# ---------------- Oreilles en T aux extrémités (côté y>=0) ----------------
def t_ear(x_sign):
    """Oreille en T au plan de joint, côté y positif, extrémité x_sign*R."""
    y0, y1s, y1c = GAP / 2, GAP / 2 + 2 * STEM_HW, GAP / 2 + 2 * CAP_HW
    h = EAR_Z1 - EAR_Z0
    stem = box(extents=[STEM_R1 - STEM_R0, y1s - y0, h])
    stem.apply_translation([x_sign * (STEM_R0 + STEM_R1) / 2, (y0 + y1s) / 2, EAR_Z0 + h / 2])
    cap = box(extents=[CAP_R1 - CAP_R0, y1c - y0, h])
    cap.apply_translation([x_sign * (CAP_R0 + CAP_R1) / 2, (y0 + y1c) / 2, EAR_Z0 + h / 2])
    return trimesh.boolean.union([stem, cap], engine='manifold')

ears = trimesh.boolean.union([t_ear(+1), t_ear(-1)], engine='manifold')

# ---------------- Demi-anneau (y >= GAP/2) ----------------
big = 400.0
keep = box(extents=[big, big, big])
keep.apply_translation([0, big / 2 + GAP / 2, 0])
half = trimesh.boolean.intersection([ring, keep], engine='manifold')
half = trimesh.boolean.union([half, ears], engine='manifold')
assert half.is_watertight, "demi-anneau non étanche"

# ---------------- Clip en C (coulisse verticalement sur les 2 oreilles) ----------------
CL = 0.25                      # jeu d'ajustement
cap_y  = 2 * CAP_HW + GAP / 2  # demi-largeur du bloc têtes assemblé (~6.15)
stem_y = 2 * STEM_HW + GAP / 2 # demi-largeur du bloc pieds (~3.15)
W = 2.5                        # épaisseur parois clip
H = 12.0                       # hauteur clip

body = box(extents=[(CAP_R1 - CAP_R0) + 2 * CL + 2 * W + 1.5, 2 * (cap_y + CL + W), H])
body.apply_translation([(CAP_R0 - CL - 1.5 + CAP_R1 + CL + W) / 2, 0, H / 2])
cav_cap = box(extents=[(CAP_R1 - CAP_R0) + 2 * CL, 2 * (cap_y + CL), H + 2])
cav_cap.apply_translation([(CAP_R0 + CAP_R1) / 2, 0, H / 2])
cav_stem = box(extents=[(STEM_R1 - STEM_R0) + 4, 2 * (stem_y + CL), H + 2])
cav_stem.apply_translation([STEM_R0 + (STEM_R1 - STEM_R0) / 2 - 1, 0, H / 2])
clip = trimesh.boolean.difference([body, cav_cap, cav_stem], engine='manifold')
clip.apply_translation([-clip.bounds[0][0], 0, 0])  # poser au sol
assert clip.is_watertight, "clip non étanche"

# ---------------- Exports ----------------
half.export('/home/claude/piege_fourmis_demi_anneau.stl')
clip.export('/home/claude/piege_fourmis_clip.stl')

# Assemblage de visualisation
half_b = half.copy()
half_b.apply_transform(trimesh.transformations.rotation_matrix(np.pi, [0, 0, 1]))
clip_a = clip.copy(); clip_a.apply_translation([CAP_R0 - CL - 1.5 - clip_a.bounds[0][0] + 0, 0, EAR_Z0])
# repositionner le clip sur les oreilles (x aligné sur les T)
clip_a = clip.copy()
clip_a.apply_translation([CAP_R0 - CL - 1.5, 0, EAR_Z0])
clip_b = clip_a.copy()
clip_b.apply_transform(trimesh.transformations.rotation_matrix(np.pi, [0, 0, 1]))
assembly = trimesh.util.concatenate([half, half_b, clip_a, clip_b])
assembly.export('/home/claude/piege_fourmis_assemblage.stl')

for name, m in [('demi-anneau', half), ('clip', clip)]:
    print(f"{name}: watertight={m.is_watertight}, bbox={np.round(m.extents,1)} mm, vol={m.volume/1000:.1f} cm3")
print(f"assemblage: bbox={np.round(assembly.extents,1)} mm")
