"""
Generateur STL pour carte de menu restaurant (QR + NFC).
Produit DEUX STL qui s'imbriquent pour impression multicouleur Bambu P1S + AMS :
  - <nom>_base.stl   : la plaque (Couleur 1)
  - <nom>_relief.stl : texte + QR en relief (Couleur 2)
Les deux partagent le meme repere -> dans Bambu Studio : importer les 2,
clic droit > "Assemble" (ou aligner), assigner une couleur AMS a chaque objet.
"""
import numpy as np
import trimesh
from trimesh.creation import extrude_polygon
from shapely.geometry import Polygon, MultiPolygon, box as shp_box
from shapely.ops import unary_union
from shapely.affinity import translate as shp_translate, scale as shp_scale
from PIL import Image, ImageFont, ImageDraw
import qrcode
import os, io

import platform

def _find_fonts():
    sys = platform.system()
    if sys == "Darwin":  # macOS
        return {
            "sans":  "/System/Library/Fonts/Helvetica.ttc",
            "serif": "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf",
            "mono":  "/System/Library/Fonts/Menlo.ttc",
        }
    elif sys == "Windows":
        return {
            "sans":  "C:/Windows/Fonts/arialbd.ttf",
            "serif": "C:/Windows/Fonts/timesbd.ttf",
            "mono":  "C:/Windows/Fonts/consolab.ttf",
        }
    else:  # Linux
        return {
            "sans":  "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "serif": "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf",
            "mono":  "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf",
        }

FONTS = _find_fonts()

# ---------- utilitaires geometrie ----------

def rounded_rect(w, d, r):
    """Rectangle centre a coins arrondis (shapely)."""
    r = min(r, w/2 - 0.01, d/2 - 0.01)
    if r <= 0:
        return shp_box(-w/2, -d/2, w/2, d/2)
    return shp_box(-w/2, -d/2, w/2, d/2).buffer(0).intersection(
        shp_box(-w/2, -d/2, w/2, d/2)
    ).buffer(-r, join_style=1).buffer(r, join_style=1)

def text_to_polygons(text, font_path, target_h_mm, px_per_mm=10):
    """Rasterise un texte puis vectorise en polygones shapely (en mm, centre en x)."""
    fontsize = int(target_h_mm * px_per_mm)
    font = ImageFont.truetype(font_path, fontsize)
    # mesure
    tmp = Image.new("L", (10, 10))
    d = ImageDraw.Draw(tmp)
    bbox = d.textbbox((0, 0), text, font=font)
    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
    pad = fontsize // 4
    img = Image.new("L", (tw + 2*pad, th + 2*pad), 0)
    d = ImageDraw.Draw(img)
    d.text((pad - bbox[0], pad - bbox[1]), text, fill=255, font=font)
    arr = np.array(img)
    return _raster_to_polys(arr, px_per_mm)

def _raster_to_polys(arr, px_per_mm):
    """Bitmap -> MultiPolygon (mm), via contours marching squares."""
    from skimage import measure
    h, w = arr.shape
    # padding pour fermer les contours au bord
    arr = np.pad(arr, 1, mode="constant", constant_values=0)
    contours = measure.find_contours(arr, 128)
    polys = []
    for c in contours:
        # c = (row, col) -> (x=col, y=row), y inverse pour orientation correcte
        pts = [(col/px_per_mm, -row/px_per_mm) for row, col in c]
        if len(pts) >= 4:
            p = Polygon(pts)
            if p.is_valid and p.area > 0.05:
                polys.append(p)
    if not polys:
        return MultiPolygon([])
    # resoudre trous (lettres O, A, e...) : difference des polys contenus
    polys.sort(key=lambda p: p.area, reverse=True)
    result = None
    for p in polys:
        result = p if result is None else result.symmetric_difference(p)
    if isinstance(result, Polygon):
        result = MultiPolygon([result])
    return result

def qr_to_polygons(data, target_size_mm, module_margin=0.0):
    """Genere un QR et le convertit en MultiPolygon (carres des modules sombres)."""
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    matrix = qr.get_matrix()
    n = len(matrix)
    cell = target_size_mm / n
    squares = []
    for i, row in enumerate(matrix):
        for j, val in enumerate(row):
            if val:
                x0 = j*cell + module_margin
                y0 = (n-1-i)*cell + module_margin
                squares.append(shp_box(x0, y0, x0+cell-module_margin, y0+cell-module_margin))
    qrpoly = unary_union(squares)
    # centrer sur 0
    qrpoly = shp_translate(qrpoly, -target_size_mm/2, -target_size_mm/2)
    return qrpoly

def poly_to_mesh(poly, z0, height):
    """Extrude un (Multi)Polygon shapely en mesh trimesh a partir de z0."""
    if poly.is_empty:
        return None
    geoms = poly.geoms if isinstance(poly, MultiPolygon) else [poly]
    meshes = []
    for g in geoms:
        if g.area <= 0:
            continue
        try:
            m = extrude_polygon(g, height)
            m.apply_translation([0, 0, z0])
            meshes.append(m)
        except Exception:
            continue
    if not meshes:
        return None
    return trimesh.util.concatenate(meshes)


# ---------- generation principale ----------

def generate(params):
    name        = params["restaurant"]
    qr_data     = params.get("qr_link", "")
    subtitle    = params.get("subtitle", "Scannez pour le menu")
    width       = float(params["width"])      # mm
    depth       = float(params["depth"])      # mm
    base_h      = float(params["base_height"])# mm epaisseur plaque
    relief_h    = float(params.get("relief_height", 0.6))  # mm hauteur relief
    radius      = float(params["radius"])     # mm arrondi bordure
    font_key    = params.get("font", "sans")
    outdir      = params["outdir"]
    safe        = "".join(c if c.isalnum() else "_" for c in name)[:40] or "menu"

    font_path = FONTS.get(font_key, FONTS["sans"])

    # 1) PLAQUE DE BASE
    base_poly = rounded_rect(width, depth, radius)
    base_mesh = extrude_polygon(base_poly, base_h)
    # plaque posee : sa face sup a z = base_h, relief par dessus

    # 2) RELIEF : titre + sous-titre + QR
    relief_parts = []
    top = depth/2

    # --- Titre ---
    title_h = min(depth*0.12, 9.0)
    tpoly = text_to_polygons(name, font_path, title_h)
    if not tpoly.is_empty:
        minx, miny, maxx, maxy = tpoly.bounds
        # centrer horizontalement, placer en haut
        tpoly = shp_translate(tpoly, -(minx+maxx)/2, 0)
        ty = top - title_h - depth*0.06
        tpoly = shp_translate(tpoly, 0, ty - miny if False else (ty))
        # recadrer y proprement
        minx, miny, maxx, maxy = tpoly.bounds
        tpoly = shp_translate(tpoly, 0, (top - depth*0.06 - maxy))
        relief_parts.append(tpoly)

    # --- QR au centre ---
    qr_size = min(width, depth) * 0.42
    qpoly = qr_to_polygons(qr_data or "https://", qr_size)
    qpoly = shp_translate(qpoly, 0, -depth*0.04)
    relief_parts.append(qpoly)
    qr_bounds = qpoly.bounds

    # --- Sous-titre sous le QR ---
    sub_h = min(depth*0.06, 4.0)
    spoly = text_to_polygons(subtitle, font_path, sub_h)
    if not spoly.is_empty:
        minx, miny, maxx, maxy = spoly.bounds
        spoly = shp_translate(spoly, -(minx+maxx)/2, 0)
        minx, miny, maxx, maxy = spoly.bounds
        sy_target = qr_bounds[1] - sub_h*0.8   # juste sous le QR
        spoly = shp_translate(spoly, 0, sy_target - maxy)
        relief_parts.append(spoly)

    # --- pictogramme NFC (petit "wifi" stylise) en bas ---
    # union de tout le relief, clip dans la plaque
    relief_union = unary_union([p for p in relief_parts if not p.is_empty])
    relief_union = relief_union.intersection(base_poly.buffer(-1.0))

    relief_mesh = poly_to_mesh(relief_union, base_h - 0.01, relief_h + 0.01)

    # exports
    base_path   = os.path.join(outdir, f"{safe}_base.stl")
    relief_path = os.path.join(outdir, f"{safe}_relief.stl")
    base_mesh.export(base_path)
    if relief_mesh is not None:
        relief_mesh.export(relief_path)

    # preview PNG (vue de dessus)
    prev_path = os.path.join(outdir, f"{safe}_preview.png")
    _preview(base_poly, relief_union, width, depth, prev_path,
             params.get("color1","#1b3a2f"), params.get("color2","#d4af37"))

    return {
        "base": base_path, "relief": relief_path, "preview": prev_path,
        "safe": safe,
        "base_faces": len(base_mesh.faces),
        "relief_faces": len(relief_mesh.faces) if relief_mesh else 0,
        "watertight_base": bool(base_mesh.is_watertight),
    }


def _preview(base_poly, relief_poly, w, d, path, c1, c2):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path as MPath

    fig, ax = plt.subplots(figsize=(6, 6*d/w))
    ax.set_facecolor("#00000000")

    def draw_poly(poly, color, z, holecolor):
        geoms = poly.geoms if hasattr(poly, "geoms") else [poly]
        for g in geoms:
            if g.is_empty: continue
            xs, ys = g.exterior.xy
            ax.fill(xs, ys, color=color, zorder=z)
            for ring in g.interiors:
                xs, ys = ring.xy
                ax.fill(xs, ys, color=holecolor, zorder=z+0.1)  # trous -> couleur plaque

    # base
    geoms = base_poly.geoms if hasattr(base_poly,"geoms") else [base_poly]
    for g in geoms:
        xs, ys = g.exterior.xy
        ax.fill(xs, ys, color=c1, zorder=1)
    draw_poly(relief_poly, c2, 2, c1)
    ax.set_xlim(-w/2-2, w/2+2); ax.set_ylim(-d/2-2, d/2+2)
    ax.set_aspect("equal"); ax.axis("off")
    plt.savefig(path, dpi=130, bbox_inches="tight", transparent=True)
    plt.close()


if __name__ == "__main__":
    os.makedirs("/home/claude/menu_gen/out", exist_ok=True)
    r = generate({
        "restaurant": "Le Petit Marseillais",
        "qr_link": "https://menu.lepetitmarseillais.fr",
        "subtitle": "Scannez ou approchez votre tel",
        "width": 90, "depth": 120, "base_height": 3, "relief_height": 0.8,
        "radius": 8, "font": "serif", "outdir": "/home/claude/menu_gen/out",
        "color1": "#1b3a2f", "color2": "#d4af37",
    })
    print(r)
