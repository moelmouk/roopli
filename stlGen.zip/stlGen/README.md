# Générateur de carte menu — STL multicouleur (Bambu P1S + AMS)

Interface web qui génère **2 fichiers STL** s'imbriquant pour une impression
bi-couleur : la plaque (couleur 1) + le texte et le QR code en relief (couleur 2).

## Lancer

```bash
pip install -r requirements.txt
# sous Debian/Ubuntu, pour le rendu QR : sudo apt install libzbar0 (optionnel, validation seulement)
python app.py
```

Ouvre ensuite **http://localhost:5000**

## Le formulaire

- **Nom du restaurant** + sous-titre
- **Lien QR** : l'URL encodée dans le QR code (le menu)
- **Lien NFC** : information seulement, à encoder toi-même sur l'étiquette NFC (voir plus bas)
- **Police** : sans / serif / mono
- **Format** : largeur, hauteur, arrondi des bordures (mm)
- **Épaisseurs** : plaque + hauteur du relief texte/QR (mm)
- **Couleurs** : aperçu uniquement — les vraies couleurs sont tes bobines AMS

## Impression multicouleur (Bambu Studio)

1. Importer **les deux STL ensemble** → accepter « charger comme un seul objet à plusieurs pièces ».
2. Ils sont déjà alignés dans le même repère.
3. Assigner une bobine AMS à chaque pièce :
   - `_base`   → Couleur 1 (plaque)
   - `_relief` → Couleur 2 (texte + QR)
4. Trancher, imprimer.

Le relief fait < 1 mm : il est posé sur la plaque, donc imprimé en dernier au-dessus.
Contraste de couleur **et** de hauteur → le QR reste parfaitement scannable.

## NFC

Coller une étiquette NFC (NTAG213/215) sous la plaque. Encoder l'URL avec
l'app **NFC Tools** (Android/iOS). Pour un logement dédié dans la plaque,
me le demander — facile à ajouter au générateur.

## Fichiers

- `app.py` — serveur Flask
- `generator.py` — moteur de génération (texte/QR vectorisés → mesh)
- `templates/index.html` — interface
- `out/` — fichiers générés
