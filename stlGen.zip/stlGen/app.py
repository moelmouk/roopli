"""
Serveur web du generateur de carte menu restaurant.
Lancer : python app.py  ->  http://localhost:5000
"""
from flask import Flask, request, jsonify, send_file, render_template, send_from_directory
import os, tempfile, traceback, zipfile, io
from generator import generate

app = Flask(__name__)
OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def do_generate():
    try:
        p = request.get_json()
        params = {
            "restaurant":   p.get("restaurant", "Restaurant").strip(),
            "qr_link":      p.get("qr_link", "").strip(),
            "nfc_link":     p.get("nfc_link", "").strip(),
            "subtitle":     p.get("subtitle", "Scannez pour le menu").strip(),
            "width":        max(40, min(300, float(p.get("width", 90)))),
            "depth":        max(40, min(300, float(p.get("depth", 120)))),
            "base_height":  max(1, min(10, float(p.get("base_height", 3)))),
            "relief_height":max(0.2, min(3, float(p.get("relief_height", 0.8)))),
            "radius":       max(0, min(40, float(p.get("radius", 8)))),
            "font":         p.get("font", "sans"),
            "color1":       p.get("color1", "#1b3a2f"),
            "color2":       p.get("color2", "#d4af37"),
            "outdir":       OUT,
        }
        res = generate(params)
        return jsonify({"ok": True, **res,
                        "preview_url": f"/file/{os.path.basename(res['preview'])}"})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/file/<path:fn>")
def serve_file(fn):
    return send_from_directory(OUT, fn)

@app.route("/download/<safe>")
def download_zip(safe):
    mem = io.BytesIO()
    with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as z:
        for suffix in ("_base.stl", "_relief.stl"):
            fp = os.path.join(OUT, safe + suffix)
            if os.path.exists(fp):
                z.write(fp, safe + suffix)
        # notice d'assemblage
        z.writestr("LISEZ_MOI.txt", ASSEMBLY_NOTE)
    mem.seek(0)
    return send_file(mem, mimetype="application/zip", as_attachment=True,
                     download_name=f"{safe}_menu_stl.zip")

ASSEMBLY_NOTE = """CARTE MENU - 2 fichiers STL pour impression multicouleur (Bambu P1S + AMS)

1. Ouvrir Bambu Studio
2. Importer les DEUX fichiers (_base.stl et _relief.stl) en meme temps
   -> Bambu propose "Charger comme un seul objet avec plusieurs pieces ?" -> OUI
   (sinon : selectionner les 2 objets > clic droit > Assembler)
3. Les deux pieces sont deja alignees dans le meme repere.
4. Assigner les couleurs AMS :
   - _base   = Couleur 1 (la plaque)
   - _relief = Couleur 2 (texte + QR)
   Clic sur l'objet > palette de couleur > choisir la bobine AMS.
5. Trancher et imprimer. Le relief fait < 1 mm : prevoir assez de couches
   du dessus pour le couvrir si besoin (laisser >= 3 couches superieures).

NFC : coller une etiquette NFC (NTAG213/215) sous la plaque, ou prevoir
un logement (option a venir). Encoder le lien avec NFC Tools (Android/iOS).
"""

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
